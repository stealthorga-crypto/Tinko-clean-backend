# app/services/email_service.py

import os
import logging
from fastapi import HTTPException
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content

logger = logging.getLogger(__name__)

# Load from .env
SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
FROM_EMAIL = os.getenv("SENDGRID_FROM_EMAIL")

if not SENDGRID_API_KEY:
    logger.error("❌ SENDGRID_API_KEY missing in environment.")
if not FROM_EMAIL:
    logger.error("❌ SENDGRID_FROM_EMAIL missing in environment.")


# ---------------------------------------------------------
# GENERIC EMAIL SENDER  → all emails use this base function
# ---------------------------------------------------------
async def send_email(
    to_email: str,
    subject: str,
    body_text: str,
    body_html: str,
    category: str = "general"
):
    """
    Universal SendGrid email sender.
    Can be used for:
      - OTP
      - Signup confirmation
      - Alerts
      - Notifications
      - Custom templates
    """

    if not SENDGRID_API_KEY or not FROM_EMAIL:
        raise HTTPException(
            status_code=500,
            detail="Email service is not configured properly."
        )

    message = Mail(
        from_email=Email(FROM_EMAIL),
        to_emails=To(to_email),
        subject=subject,
        plain_text_content=Content("text/plain", body_text),
        html_content=Content("text/html", body_html),
    )

    # Add category for SendGrid Analytics
    message.category = category

    try:
        sg = SendGridAPIClient(SENDGRID_API_KEY)
        response = sg.send(message)

        logger.info(f"📧 Email sent to {to_email}, Status: {response.status_code}")
        return True

    except Exception as e:
        logger.error(f"❌ SendGrid email sending failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"SendGrid failed to send email: {str(e)}"
        )


# ---------------------------------------------------------
# OTP EMAIL TEMPLATE (Reusable)
# ---------------------------------------------------------
def build_otp_template(otp: str):
    """
    Reusable OTP HTML template
    """

    body_text = f"Your Tinko verification code is {otp}. It is valid for 5 minutes."

    body_html = f"""
        <div style="font-family:Arial; padding:20px; background:#fafafa;">
            <h2 style="color:#F4511E;">Your Tinko Verification Code</h2>
            <p>Please use the OTP below to continue:</p>
            <h1 style="font-size:40px; color:#000; letter-spacing:4px;">{otp}</h1>
            <p style="margin-top:20px;">This OTP is valid for <b>5 minutes</b>.</p>
            <br>
            <small>If you did not request this, you can safely ignore this email.</small>
        </div>
    """

    return body_text, body_html


# ---------------------------------------------------------
# SEND OTP EMAIL (Production Ready)
# ---------------------------------------------------------
async def send_email_otp(to_email: str, otp: str):
    """
    Sends OTP email using SendGrid (production).
    Uses the generic send_email() function.
    """

    body_text, body_html = build_otp_template(otp)

    return await send_email(
        to_email=to_email,
        subject="Your Tinko Verification Code",
        body_text=body_text,
        body_html=body_html,
        category="otp"
    )


# ---------------------------------------------------------
# SAMPLE: PUBLIC REUSABLE EMAIL (Signup, Invoice, Alerts)
# ---------------------------------------------------------
async def send_generic_notification(to_email: str, title: str, message: str):
    """
    For custom notifications like:
      - Account created
      - Invoice generated
      - Payment alerts
      - Important updates
    """

    body_html = f"""
        <div style="font-family:Arial; padding:20px;">
            <h2 style="color:#F4511E;">{title}</h2>
            <p>{message}</p>
            <br>
            <small>Tinko – The Moment That Matters, Saved.</small>
        </div>
    """

    return await send_email(
        to_email=to_email,
        subject=title,
        body_text=message,
        body_html=body_html,
        category="notification"
    )
