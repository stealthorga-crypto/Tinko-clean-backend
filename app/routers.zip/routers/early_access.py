from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import requests

router = APIRouter(prefix="/v1/early-access", tags=["Early Access"])


class EarlyAccessRequest(BaseModel):
    email: str
    company: str | None = None


@router.post("/signup")
async def early_access_signup(data: EarlyAccessRequest):
    """
    Save early-access signup into Supabase
    + Send email notification to info@tinko.in
    """

    # 1️⃣ SAVE IN SUPABASE (REST API)
    SUPABASE_URL = os.getenv("SUPABASE_URL")
    SERVICE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

    insert_url = f"{SUPABASE_URL}/rest/v1/early_access"

    payload = {
        "email": data.email,
        "company": data.company
    }

    headers = {
        "apikey": SERVICE_KEY,
        "Authorization": f"Bearer {SERVICE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
    }

    try:
        r = requests.post(insert_url, json=payload, headers=headers)
        if r.status_code >= 400:
            raise Exception(r.text)
    except Exception as e:
        print("Supabase DB Error:", e)
        raise HTTPException(status_code=500, detail="Could not save signup to database")

    # 2️⃣ SEND EMAIL TO YOU
    email_body = f"""
        <h2>New Early Access Signup</h2>
        <p><strong>Email:</strong> {data.email}</p>
        <p><strong>Company:</strong> {data.company or 'Not provided'}</p>
    """

    message = Mail(
        from_email="info@tinko.in",
        to_emails="info@tinko.in",
        subject="New Early Access Signup",
        html_content=email_body
    )

    try:
        sg = SendGridAPIClient(os.getenv("SENDGRID_API_KEY"))
        sg.send(message)
    except Exception as e:
        print("SendGrid Error:", e)
        raise HTTPException(status_code=500, detail="Email sending failed")

    return {"message": "Signup received"}
